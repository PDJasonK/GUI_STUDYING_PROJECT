package AdminReading;

public class AdminReading1Vo {
	private String sending1;

 

	public AdminReading1Vo(String sending1) {
		this.sending1 = sending1;
	}

	public String getsending1() {
		return sending1;
	}

}
