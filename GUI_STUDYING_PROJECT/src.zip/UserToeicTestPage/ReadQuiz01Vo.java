package UserToeicTestPage;

public class ReadQuiz01Vo {

	private String sending1;

	 

	public ReadQuiz01Vo(String sending1) {
		this.sending1 = sending1;
	}

	public String getsending1() {
		return sending1;
	}

}
