package AdminReadingQuiz;

public class AdminReadingQuiz1Vo {

	private String sending1;

	 

	public AdminReadingQuiz1Vo(String sending1) {
		this.sending1 = sending1;
	}

	public String getsending1() {
		return sending1;
	}

}
