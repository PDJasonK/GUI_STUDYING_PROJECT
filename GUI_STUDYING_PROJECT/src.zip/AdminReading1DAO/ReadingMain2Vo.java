package AdminReading1DAO;

public class ReadingMain2Vo {

	private String gain1;

	private String send1;

	ReadingMain2Vo() {

	}

	public ReadingMain2Vo(String gain1, String gain2, String gain3, String send1, String send2, String send3) {
		this.gain1 = gain1;

		this.send1 = send1;

	}

	public String getgain1() {
		return gain1;
	}

	public String getsend1() {
		return send1;
	}

}