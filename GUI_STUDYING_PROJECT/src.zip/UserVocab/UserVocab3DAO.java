package UserVocab;

public class UserVocab3DAO {

}
