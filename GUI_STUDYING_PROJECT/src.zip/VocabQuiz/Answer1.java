package VocabQuiz;

public class Answer1 {

}
