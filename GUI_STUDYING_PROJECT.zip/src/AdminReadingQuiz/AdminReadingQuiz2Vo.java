package AdminReadingQuiz;

public class AdminReadingQuiz2Vo {

 

private String sending1;



public AdminReadingQuiz2Vo (String sending1) {
	this.sending1 = sending1;
}

public String getsending1() {
	return sending1;
}

}
