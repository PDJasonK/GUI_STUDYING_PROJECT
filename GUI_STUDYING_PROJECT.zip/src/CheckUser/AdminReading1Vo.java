package CheckUser;

public class AdminReading1Vo {

}
