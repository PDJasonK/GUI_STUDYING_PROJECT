package AdminReading;

public class AdminReading2Vo {
	private String sending1;

	public AdminReading2Vo() {

	}

	public AdminReading2Vo(String sending1) {
		this.sending1 = sending1;
	}

	public String getsending1() {
		return sending1;
	}

}
