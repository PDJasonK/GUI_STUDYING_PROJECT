package UserToeicReadingContent;

public class ReadingMain1Vo {
	private String sending1;
	private String reading1;

	public ReadingMain1Vo(String sending1, String reading1) {
		this.sending1 = sending1;
		this.reading1 = reading1;

	}

	public String getsending1() {
		return sending1;
	}

	public String getreading1() {
		return reading1;
	}

}
