package AdminVocab;

 


public class VocabToeic2MainOutVo {
	private String Output1;
	private String Output2;
	private String Output3;
	private String Output4;
	private String Output5;
	private String Output6;
	private String Output7;
	private String Output8;
	private String Output9;
	private String Output10;
	private String Output11;
	private String Output12;
	private String Output13;
	private String Output14;
	private String Output15;
	private String Output16;
	public VocabToeic2MainOutVo() {

	}

	public VocabToeic2MainOutVo(String Output1, String Output2, String Output3,
			String Output4 ,String Output5 , String Output6 ,String Output7 ,String Output8,String Output9 ,String Output10 ,String Output11,String Output12
			,String Output13 ,String Output14,String Output15,String Output16) {
		this.Output1 = Output1;
		this.Output2 = Output2;
		this.Output3 = Output3;
		this.Output4 = Output4;
		this.Output5 = Output5;
		this.Output6 = Output6;
		this.Output7 = Output7;
		this.Output8 = Output8;
		this.Output9 = Output9;
		this.Output10 = Output10;
		this.Output11 = Output11;
		this.Output12 = Output12;
		this.Output13 = Output13;
		this.Output14 = Output14;
		this.Output15 = Output15;
		this.Output16 = Output16;
				
	}

	public String getOutput1() {
		return Output1;
	}

	public String getOutput2() {
		return Output2;
	}

	public String getOutput3C() {
		return Output3;
	}
	
	public String getOutput4() {
		return Output4;
	}

	public String getOutput5() {
		return Output5;
	}

	public String getOutput6() {
		return Output6;
	}
	public String getOutput7() {
		return Output7;
	}
	public String getOutput8() {
		return Output8;
	}
	public String getOutput9() {
		return Output9;
	}

	public String getOutput10() {
		return Output10;
	}
	public String getOutput11() {
		return Output11;
	}
	public String getOutput12() {
		return Output12;
	}
	public String getOutput13() {
		return Output13;
	}
	public String getOutput14() {
		return Output14;
	}
	public String getOutput15() {
		return Output15;
	}
	public String getOutput16() {
		return Output16;
	}

}