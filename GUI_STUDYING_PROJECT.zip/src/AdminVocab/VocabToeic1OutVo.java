package AdminVocab;

public class VocabToeic1OutVo {
	private String Output1;
	private String Output2;
	private String Output3;
	private String Output4;
	private String Output5;
	private String Output6;
	private String Output7;
	private String Output8;

	
	public VocabToeic1OutVo() {

	}

	public VocabToeic1OutVo(String Output1, String Output2, String Output3,
			String Output4 ,String Output5 , String Output6 ,String Output7 ,String Output8) {
		this.Output1 = Output1;
		this.Output2 = Output2;
		this.Output3 = Output3;
		this.Output4 = Output4;
		this.Output5 = Output5;
		this.Output6 = Output6;
		this.Output7 = Output7;
		this.Output8 = Output8;

		
	}

	public String getOutput1() {
		return Output1;
	}

	public String getOutput2() {
		return Output2;
	}

	public String getOutput3C() {
		return Output3;
	}
	
	public String getOutput4() {
		return Output4;
	}

	public String getOutput5() {
		return Output5;
	}

	public String getOutput6() {
		return Output6;
	}
	public String getOutput7() {
		return Output7;
	}
	public String getOutput8() {
		return Output8;
	}

}