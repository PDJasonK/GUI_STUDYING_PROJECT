package AAdminListening;

public class Listening01vo {
	private String listen1;
	private String listen2;

	public Listening01vo(String listen1, String listen2) {
		this.listen1 = listen1;
		this.listen2 = listen2;

	}

	public String getlisten1() {
		return listen1;

	}

	public String getlisten2() {
		return listen2;

	}

}
