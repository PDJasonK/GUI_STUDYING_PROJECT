package VocabQuiz;

public class QuizSenderChecker {

}
