package VocabQuiz;

public class Answer2 {

}
